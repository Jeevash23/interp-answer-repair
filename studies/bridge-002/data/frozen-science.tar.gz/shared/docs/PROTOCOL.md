# Bridge 001: answer recovery and downstream dependency transport

Protocol written 8 September 2026 before new model outcomes. This is a local
pre-outcome freeze, not public preregistration. This project preserves the two
previous studies. It tests a connection between them rather than assuming that
results on different models and tasks establish a dissociation.

## Question and primary comparison

On the same recipient examples and interventions, does cross-condition answer
recovery coincide with movement toward the clean donor's downstream dependency
signature? The two crossed prompt factors are canonical/controlled wording and
ABBA/BABA order. The primary model is the cached GPT-2 Medium. GPT-2 Small is a
predeclared, narrower within-family replication if feasible; it is not a
cross-architecture replication. No model weights are updated or downloaded.

All prompts use new complete template texts and names absent from both prior
projects' recorded manifests. Four discovery, four development and eight test
template pairs each use four disjoint name pairs per split, both entity-role
assignments, both orders and both wording conditions. This is 128 discovery,
128 development and 256 test recipient cells, with 16 test wording templates
organized as eight paired template blocks. Within a split, alternative answers
come from the next name pair. No outcomes determine template or name inclusion.
Every generated name and filler slot must be one GPT-2 token; exact tokens,
positions and donor maps are saved before inference. All rows are retained.

## Measurements

The response metrics are IO-minus-subject logit difference, probability difference,
pairwise correctness and full-vocabulary top-1 correctness. Corruption replaces
the repeated subject S2 with the recorded third name while preserving scoring
against the original IO and subject. Recovery is edited minus corrupted response.
Report raw recovery and the ratio of aggregate recovery to aggregate target
clean-minus-corrupt response. Suppress ratios for denominators below 0.1 logits
or 0.01 probability units; never interpret normalized direction as raw superiority.

Medium interventions at residual input layer 13 or earlier precede all 176
measured END heads in layers 13--23. Historical S2 head groups are a fixed union
of the earlier canonical/controlled selections (all before layer 13), used for
both directions. Small uses residual input layer 7, all 60 END heads in layers
7--11, and the earlier published Duplicate/Induction group. No downstream head
selection uses bridge outcomes. Each measured head is ablated separately.

Two reference interventions use zero or a single discovery-clean mean END-head
vector, pooled over balanced wording/order cells. The same bank is used for every
prompt and edit. This common reference makes donor/recipient signatures directly
comparable without changing the replacement bank with prompt identity. It differs
from study 002's recipient-specific S2-corruption bank; conclusions must disclose
this difference. An edit is active in both terms of every causal-effect contrast.
Save logit and probability signatures, not just aggregate scores.

Standardization uses discovery within-four-cell SDs with a 0.1-logit floor.
Discovery centroids define separate wording and order axes, stratified by the
other factor. Scales and axes are frozen before test. Report movement from the
natural clean recipient along the donor-oriented axis (S), perpendicular movement
(O), changes from the corrupted recipient, and distances to the actual matched
clean donor and recipient signatures, normalized by discovery centroid distance.
Changing a signature of individual-head dependencies is not proof of complete
circuit transfer, sufficiency or unique pathway identity.

## Interventions and controls

All edits use semantic S2 alignment. For each test recipient:

- Natural clean and corrupted runs provide behavior/signature references.
- Historical head-union transport adds clean-minus-corrupt source head-result
  differences into the live corrupted recipient: own source, other wording,
  or opposite order. Three per-ID random residual directions preserve each
  head-result norm of the other-wording transport control.
- Full residual replacement uses own clean state in corrupted recipients, or
  other-wording/opposite-order clean donor states in corrupted and clean recipients.
- Rank-one replacement projects donor-minus-current state onto a discovery ridge
  direction. Separate fixed-site predictors target the mean standardized wording
  or order coordinate across the two baselines. Development scores are reported;
  they do not trigger selecting a new site or direction. A four-cell prompt-label
  mean is a prespecified prediction baseline. Prediction is not causal evidence.
- For corrupted recipients, scaled full-vector edits match the corresponding
  rank-one norm, and three random directions per factor match that same norm.
- Other-wording and opposite-order full replacements with a changed donor answer
  are tested on both clean and corrupted recipients; record alternative-answer
  intrusion. They do not by themselves establish abstract or answer-invariant routing.

There are 27 nontrivial edit conditions per test cell (six head conditions,
five full-state conditions, four rank-one conditions, two matched full-state
conditions, six rank-norm random controls, four changed-answer conditions).
Different multi-head versus single-state interventions are not claimed to have
equal effective dose. Equal residual norm does not equal equal functional impact.

## Validation and decision rules

Technical validation uses already observed pilot prompts, not bridge test prompts.
Check full-forward versus cached-suffix logits, nested edit/head effects, zero
edits, additive head-result equivalence, and batch expansion at float32 tolerance
0.0005. GPU execution uses full float32 and disables reduced-precision matmuls.
A whole-boundary clean-state transplant must recover the clean endpoint and
individual-head signature within tolerance. This is a computational positive
control, not evidence that a compact router exists or that the assay captures all
meaningful mechanisms. Own-clean S2 restoration is an empirical repair control.

Report clean behavior and natural family separation separately for every wording/
order cell. Interpret a robust switch only if natural pairwise/top-1 behavior and
family classification pass 75% gates. Report confidence intervals even when gates
fail. Invalid controlled behavior limits recovery interpretation and never causes
example deletion. Independent template/name-pair bootstrap draws preserve paired
roles, order, wording and interventions. Intervals condition on discovery fits.

The primary transfer family contains four historical-head cross-condition cells
per factor (two directions times the other factor). For each factor use
Bonferroni simultaneous intervals over eight quantities: four raw logit recovery
means and four donor-axis positions per ablation baseline as separately declared
eight-member families. Also show pointwise intervals. The central descriptive
question is whether recovery accompanies clean-donor proximity; no significance
failure is called evidence of absence. A robust finite-signature switch requires
S lower bound >0.5, mean O <= mean positive S, donor closer than clean recipient,
and pairwise accuracy within 10 percentage points of clean in all cells and both
baselines. Absence-equivalence is only reported if the simultaneous S interval
lies entirely within [-0.1, 0.1]. Failure of these operational gates is not proof
that all possible compact routers fail. Other interventions and control contrasts
are explicitly secondary with pointwise intervals and full condition reporting.

Archive scientific code/configuration/token manifests before discovery inference.
Freeze fitted references/predictors and the analyzer before test inference. If an
implementation bug is found, preserve the failed run and disclose a new freeze
or amendment. Never use test outcomes to revise axes, names, heads or gates.

## Position relative to prior work

ACC++ already studies prompt-specific ABBA/BABA and wording circuits
(https://arxiv.org/html/2602.13483v2, section 3.1). Test, then Route already uses
four-donor interventions and tests answer-bound versus transferable routing
(https://arxiv.org/html/2608.04183v1). Intervention-reference sensitivity is
established methodological context (https://arxiv.org/abs/2407.08734).
This study's candidate contribution is simultaneous behavioral recovery and
fixed downstream causal-dependency measurement under matched experimental cells.
It is not a new activation-patching method and has no established priority claim.
