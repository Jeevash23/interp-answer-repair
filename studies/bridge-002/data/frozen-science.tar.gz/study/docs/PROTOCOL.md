# Bridge 002: valid wording and causal explanation

Written 8 September 2026, after Bridge 001 and before this study's screening
outcomes. This is a prospective follow-up informed by the previous results,
with a local freeze rather than public preregistration. Bridge 001 is retained.

## Behavioral validity before transfer

The primary model is cached GPT-2 Medium; GPT-2 Small supplies a within-family
replication. Both use the unchanged float32 engine, source-head unions, residual
sites and downstream END-head measurement ranges from Bridge 001. No model is
fine-tuned. A shared environment is sufficient; this study owns its inputs and outputs.

Four grammatical candidate formulations are fixed in code before screening.
Family 0 is the canonical 'When ... went to ... gave ... to'. Choose the first
of candidates 1, 2, 3 in that order that, together with family 0, has pairwise
accuracy >=95% and vocabulary top-1 accuracy >=85% in each ABBA/BABA cell on
both models' screening data. If no pair passes, retain screening failures and
stop before test; any redesign requires a disclosed new screening stage.
Only clean behavior selects the pair, never transfer or dependency outcomes.

Screening: four location/object blocks, four disjoint name triples, two role
assignments and two orders per candidate family. Discovery: four new blocks
and four new triples. Test: eight new blocks and six new triples. Each triple
contains two possible IO/subject names and a third, exclusive corruption name.
Within a split triples do not share any name, fixing Bridge 001's overlapping
alternative-name issue. Names are disjoint across these three splits and from
Bridge 001, but are not claimed unseen in every historical project or pretraining.
Both name roles are retained. Candidate test texts are saved before screening;
test outcomes are never used to filter names, templates, families or examples.

After selection there are 128 discovery and 384 test cells shared across models.
The screening-selected families must meet the same clean accuracy thresholds on
test for claims about reliably solved tasks. Report every cell if they do not.
Discovery-only family centroids and within-cell scales (0.1-logit floor) define
wording/order axes. Report held-out family classification; do not interpret
poorly separated wording families as a successful or failed distinguishable
mechanism switch solely through an unstable normalized axis.

## Matched transfers and factorial donor test

Every test cell has these 13 edits, all starting from its corrupted prompt:

1. Own clean-minus-corrupt source-head delta.
2. Same-order donor with IO/subject roles exchanged.
3. Other-wording donor, same order and roles.
4. Other-wording donor, same order, exchanged roles.
5. Opposite-order donor, same roles.
6. Opposite-order donor, exchanged roles.
7. Half-dose other-wording delta.
8. Half-dose opposite-order delta.
9--11. Three per-recipient random head deltas matching the other-wording norms.
12--13. Full S2 state replacement from other wording or opposite order.

The own/role/order/order-plus-role donors form a 2x2 design. Exchanging roles
changes which name is the donor answer, whereas exchanging order changes where
the IO and repeated subject first appear. Their effects distinguish positional
compatibility from donor answer identity in these head-union interventions.
They do not isolate an abstract variable with no other changed features.

Measure raw logit/probability recovery, pairwise/top-1 correctness, and both
zero/discovery-mean individual-head dependency signatures. Use the same geometry
as Bridge 001 and report orthogonal movement and actual matched-donor proximity.
Head-role donors are scored against the recipient's labels. No normalized
recovery ratio is interpreted as a success percentage.

## Discovery-selected causal follow-up

Run own, wording and order head edits on discovery data. Select four downstream
heads per factor by largest mean absolute change in individual-head logit effects
between edited and corrupted runs, standardized by discovery scales and averaged
over both replacement references. Select a separate four-head reader group by
largest mean positive clean logit effect. Freeze all groups before test.

For each group generate three equal-size, layer-matched control groups excluding
the selected heads, using a fixed seed. Controls may overlap one another. They
are not asserted equal in effect strength. Save all head IDs and discovery scores.

For wording and order edits, jointly clamp the selected heads' END z vectors
to their corresponding unedited corrupted-recipient values. Recompute the edited
output and the no-edit output under the same clamp. Attenuation is the difference
between the original edit effect and the clamped edit effect. This is a controlled
intervention interaction, not an identified natural mediation effect or unique path.
Compare to all three layer-matched groups. Use the discovery sign of total
recovery to orient attenuation, so blocking an adverse order effect is not called
negative evidence merely because raw signed attenuation is negative.

Then separately clamp the selected heads' END queries, all-position keys, and
all-position values to unedited corrupted-recipient values. Save score effects
and END attention to the original IO/subject positions. These component clamps
test candidate ways the effect enters those heads; they do not form additive,
independent mediation fractions. No fractions are reported with a near-zero total.

Measure joint zero and discovery-mean ablations of the selected groups in edited
and corrupted runs, and compare their effects with the sum of the corresponding
individual-head effects. Non-additivity is measured directly rather than inferred
from a visual signature difference. These and query/key/value probes are secondary.

Own-clean head repair is an empirical causal positive control. Clamp the
discovery-selected reader group and matched controls during repair. Report whether
held-out repair is positive and whether the reader clamp attenuates it. This
calibrates a repair/blocking assay; it does not validate compact donor-circuit routing.
Whole-boundary transplant and identity checks remain numerical controls only.

## Uncertainty and claim rules

10,000 crossed template/name-triple bootstrap draws preserve every paired role,
wording, order, donor and clamp comparison. Fits and selected heads remain fixed.
This gives conditional uncertainty with only eight test blocks and six name
triples, not a broad-population guarantee.

Primary wording transfer: four raw logit recovery means and four donor-axis
positions form an eight-member Bonferroni family per replacement reference.
The stricter behavior gates above and >=75% per-cell family classification apply
to mechanism-switch interpretation. A switch additionally requires S lower bound
>0.5, mean orthogonal movement <= positive mean S, donor closer on average, and
pairwise loss <=10 percentage points in all cells and both references. No failed
gate is treated as proof of absence.

Primary factorial behavior: order main effect, role main effect and their
interaction in each of four wording/order cells form a 12-member adjusted family.
Role-effect equivalence is assessed only if its adjusted interval lies within
[-0.2, 0.2] logits. Otherwise do not claim answer identity has no effect.

Primary blocking: oriented attenuation for each factor and its advantage over
each of three matched groups form an eight-member adjusted family. Success
requires positive adjusted lower bounds for the selected group and each control
comparison. Report the signed quantities as well, with full cell breakdowns.
Other comparisons and mechanism probes use explicitly secondary pointwise intervals.

Archive the candidate design before screening. Freeze selected inputs, scientific
code, analyzer and protocol before discovery; freeze fitted references, selected
heads, controls and orientation before test. Any code amendment retains old
versions and identifies which results, if any, preceded it. Never tune on test.
