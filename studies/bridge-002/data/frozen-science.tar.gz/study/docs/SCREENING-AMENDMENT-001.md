# Additional grammatical-family screen

8 September 2026, after the first behavior-only screen and before any discovery
or test inference. The original candidate data, code freeze and failed selection
record are retained unchanged.

Medium's canonical family 0 achieved 100% pairwise accuracy but only 78.1% and
84.4% vocabulary top-1 accuracy in the two orders, below the fixed 85% threshold.
Family 1 ('After ... walked into ... handed ... to') passed on both models.
The original mandatory-family-0 rule therefore selected no pair. No transfer
or dependency results have been measured for this follow-up.

The revised screening stage fixes family 1 as its anchor and tests three new
grammatical candidates, in order: 'When ... arrived at ... handed ... to',
'While ... waited inside ... handed ... to', and 'When ... walked through ...
handed ... to'. They share 'handed ... to'; any eventual wording result will
therefore concern the prefix/location clause, not arbitrary paraphrases or verbs.

Use four new screening blocks and four new, disjoint name triples. Keep the same
95% pairwise and 85% top-1 thresholds for every family/order cell on both models.
Choose the first passing partner for the anchor. The discovery and test names,
blocks, roles, orders and sample counts remain fixed and unobserved. Save all new
candidate texts and this amendment before the second screen. A failed second
screen remains a failure and cannot authorize test-outcome filtering.

This is adaptive benchmark development on screening data, explicitly disclosed.
It is not an unchanged one-shot preregistration. Transfer analyses, causal probes,
uncertainty rules and held-out validity requirements remain as in PROTOCOL.md.
