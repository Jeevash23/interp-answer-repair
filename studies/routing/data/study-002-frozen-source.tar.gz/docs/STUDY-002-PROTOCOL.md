# Study 002: fixed-signature transfer in GPT-2 Small

Status: protocol being finalized before new study inference, 5 September 2026. This is a local
freeze, not a public preregistration. Pilot 001 remains immutable and exploratory.

## Authorization and audit limitation

The user has explicitly authorized continued experiments and a manuscript. Fresh GPU and public
paper checks were retried with that authorization; automatic approval review again failed with an
HTTP 404 before execution. The study proceeds on CPU. The prior prohibition on main-study work
pending online review is amended under the user's continuation instruction: local experiments
may proceed, but the manuscript must disclose an incomplete novelty/source audit and must not
claim first discovery or submission readiness. This does not bypass any access restriction.

## Design and phases

Use GPT-2 Small and the exact 72 downstream END-head coordinates, two replacement baselines,
endpoint, and 0.1-logit scale floor from pilot 001. Fit numerical scales and centroids anew using
only study 002 discovery data, before any routing evaluation. Preserve raw effects.

Sixteen new hand-written template texts are split into 4 discovery, 4 development and 8 test
templates before inference. Each split has four disjoint unordered name pairs. Each template
crosses both IO/subject assignments and both ABBA/BABA orders: 64 discovery, 64 development,
128 test recipient prompts. Names are disjoint across these splits and from pilot 001. Correct
answers are preserved between matched families. All failed examples remain in the report.

First evaluate discovery/development behavior and fixed signatures. A family feasibility check
requires pairwise correctness >=75% in each split/family, development nearest-centroid balanced
accuracy >=75% for each ablation baseline, and positive development paired family-axis separation.
Report open-vocabulary top-1 behavior separately; it cannot be inferred from pairwise correctness.
Open-vocabulary accuracy >=75% on each split is an additional natural-task validity criterion.
Test outcomes are not inspected until the candidate-selection file is frozen. No template or
name pair is removed using model outcomes.

## Candidate mediator selection

Candidates are residual states before layers 2, 4, and 6 at END and at the repeated subject S2.
They are strictly upstream of, or at the input to, the first measured downstream layer. For each
site, fit a ridge predictor of the discovery causal-family axis coordinate. The target averages
coordinates across the two separately standardized signature baselines; it is not merely a
surface ABBA/BABA label. Ridge penalty is fixed at 0.01 times the average centered squared state
norm. Intercept, feature mean and target mean are fit only on discovery data.

Select the site with greatest development R-squared on the downstream signature target, breaking
ties by earlier layer then END. Freeze all coefficients and the selected site before test access.
The normalized regression weight defines one candidate one-dimensional subspace. Prediction is
not causal evidence. Compare this rank-one intervention with full-vector donor replacement at the
same site, and report family classification and target-prediction error on test data separately.

## Donors and interventions

For each recipient with IO A and subject B, use a third name C from the next unordered pair in
that split, distinct from both. Every donor quadruplet crosses same/opposite family with IO A/C,
holding B and wording fixed. The same-family/same-answer/same-template cell is exactly the identity
technical control. A second wording stratum uses the next template cyclically within the same
split for all four donor cells; token positions are aligned by semantic site, not index.

Rank-one replacement adds P(donor_state - recipient_state) to the recipient state. Full-vector
replacement adds the full difference. No optimization uses test outcomes. For every edited run,
recompute all 72 head effects, keeping the edit active in both terms of the endpoint contrast.
The S2-corrupt replacement bank remains the unedited recipient's bank. The downstream set is
never rediscovered after an edit.

Controls at the selected site: all four donor cells in both wording strata; fixed seeded shuffled
donors; norm-matched random directions (three draws); the same candidate delta at the preceding
non-name token instead of the selected position; the same delta inserted three layers earlier
(clamped at layer 0); and the same norm-matched delta at layer 0's MLP output. This early MLP
is a prespecified comparison site, not a component already proven irrelevant. Save the actual
edit norms, donor IDs, positions, layer, control seed and answer intrusion. Random controls use
only the delta norm and fixed RNG seeds, not scientific outcomes.

Primary causal comparisons are opposite-family minus same-family transfer for each answer and
wording stratum, separately for rank-one and full-vector edits. Report each direction and both
ablation baselines. The four donor cells disentangle answer-token transfer from family transfer;
full-vector replacement alone does not establish an abstract router.

## Quantities and decision rules

For v = donor-family centroid - recipient-family centroid and delta_s = edited - natural signature,
S = dot(delta_s,v)/dot(v,v). Report orthogonal movement ||delta_s-S*v||/||v||, distance to the donor
centroid, raw logit/probability changes, full-vocabulary and pairwise behavior, and donor-answer
intrusion. For same-family controls, orient the axis toward the opposite family for comparability.

Use a crossed template/name-pair bootstrap with 10,000 fixed-seed draws, retaining paired families,
role assignments and the four donor cells. Intervals condition on the discovery fit. Report
per-template and per-direction results, not just pooled significance. Do not interpret compact
edit failure as proof of distributed routing.

Report individual 95% intervals and Bonferroni simultaneous intervals across the 16 primary
contrasts per intervention mode (two baselines, directions, answers and wording strata).
The simultaneous two-sided tail probability is 0.05/(2*16); the strong-result gate uses those
lower bounds. Full-vector replacement is a separately reported secondary family of contrasts.
Shuffled donors are permuted within recipient family so their opposite-family identity is
preserved while name/wording alignment is broken; abstract transfer could survive this control.

A strong transfer result requires positive opposite-minus-same family movement with the lower
95% interval >0 in both directions and both ablation baselines, persistence with changed donor
answers and wording, effects above random/wrong-site controls, pairwise accuracy loss <=10
percentage points, and no large orthogonal displacement (mean orthogonal <= mean positive S).
These are conservative operational criteria, not a universal definition of circuit switching.
All components must be evaluated and disclosed; a mixed result narrows the claim.

If the compact intervention fails, retain the result, report the full-vector contrast, and write
a bounded negative/mixed-result draft. Do not search new test-set-dependent heads, axes or layers.
A model replication is conditional on a successful core result and available approved model access.
Pythia-160M is not cached and downloading it remains blocked. Cross-model generality cannot be
claimed without that replication.

## Computational validation

A faster suffix evaluator may reuse the cached residual state just before an intervention and run
only the downstream GPT-2 blocks, with an explicit causal mask and final-token unembedding. It
must reproduce full-forward endpoints and interventions to absolute tolerance 0.0005 on technical
validation prompts, including nested router/head edits. Upstream states and non-target positions
must be unaffected where causality requires this. Saved evidence and source hashes accompany runs.
The faster evaluator changes computation scheduling, not the estimand.
